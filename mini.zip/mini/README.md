# E-Commerce-website-using-html-css-Js
  A simulation of client side e-commerce website with feature as add to cart, proceed for checkout and payment options. It simultes a shopping cart within a website
This project is made for the future ready talent internship program using azure services.
